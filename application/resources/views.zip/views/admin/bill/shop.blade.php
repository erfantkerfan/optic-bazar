@extends('admin.layouts.app')

@section('page_name', ' صورت حساب مالی سامانه ')

@section('content')

    <div class="white-box">

        <div class="portlet-body">

            @if(count($request) > 0)
            <div class="table-container">

                <table class="table table-striped table-bordered table-hover">
                    <tbody>
                    <tr role="row" class="heading">
                        <th>شماره صورت حساب</th>
                        <th>تاریخ سفارش</th>
                        <th> مبلغ کل (تومان)</th>
                        <th>شرح صورت حساب</th>
                        <th></th>
                    </tr>

                    @foreach($request as $k => $item)
                        <tr role="row" class="filter">
                            <td style="font-family: Tahoma">BOP-{{ $item['transactions_id'] . '-' . $item['order_id'] }}</td>
                            <td>{{ jdate('Y/m/d', strtotime($item['transactions_created_at'])) }}</td>
                            <td>{{ number_format($item['price']) }}</td>
                            <td>{{ $item['description'] }}</td>
                            <td>
                                <a class="btn btn-block btn-info btn-rounded" target="_blank" href="{{ url('cp-manager/orders?filter_code=BOP-' . $item['transactions_id']) }}"> مشاهده سفارش </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            {!! $request->render() !!}
            <div class="clearfix"></div>

            @else

                <div class="msg">
                    <div class="alert alert-warning alert-info" style="text-align: center">صورت حسابی یافت نشد.</div>
                </div>

            @endif


        </div>

    </div>
@endsection