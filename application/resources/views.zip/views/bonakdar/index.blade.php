@extends('bonakdar.layouts.app')

@section('page_name', 'داشبورد')

@section('content')



@endsection
